import React from "react";

function FooterApp() {
    return <footer>
    <div className="footer-copyright text-center">
      <span className="text-muted"> © 2024 | Ogi Setiawan | Dicoding </span>
    </div>
  </footer>;
}

export default FooterApp;
