import React from 'react';

function NotFoundPage() {
    return (
        <>
            <h2 className="sixth">Opps..</h2>
            <section>
                <h3>This page not Found!</h3>
            </section>
        </>
    )
}

export default NotFoundPage;