# Personal Notes V2 - Dicoding Submission (Proyek Akhir)

Proyek: Membangun SPA + API, Context, dan Hooks pada kelas [Belajar Fundamental Aplikasi Web dengan React](https://www.dicoding.com/academies/413).

## Instalasi
1. Download atau clone repo ini : `git clone https://github.com/fujianto21/personal-notes-v2.git`
2. Masuk ke direktori proyek
3. Instal dependensi dengan : `npm install`
4. Jalankan aplikasi dengan : `npm run dev`

## Demo
[https://app.fujianto21.com/personal-notes-v2](https://app.fujianto21.com/personal-notes-v2)
